function Update_All_RaspPi()
%
% Update_All_RaspPi()
% Calls Single_RaspPi_Update woth all robot domain names
%
% Liran 2020

    Single_RaspPi_Update('test-pi.labs.mae.cornell.edu')
    Single_RaspPi_Update('walle.labs.mae.cornell.edu')
    Single_RaspPi_Update('eve.labs.mae.cornell.edu')
    Single_RaspPi_Update('r2d2.labs.mae.cornell.edu')
    Single_RaspPi_Update('bb8.labs.mae.cornell.edu')
    Single_RaspPi_Update('c3po.labs.mae.cornell.edu')
    Single_RaspPi_Update('dotmatrix.labs.mae.cornell.edu')
    Single_RaspPi_Update('max.labs.mae.cornell.edu')
    Single_RaspPi_Update('baymax.labs.mae.cornell.edu')
    Single_RaspPi_Update('rachel.labs.mae.cornell.edu')
    Single_RaspPi_Update('motoko.labs.mae.cornell.edu')
end
    


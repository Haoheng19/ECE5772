This toolbox includes functions to connect and communicate with the Raspberry Pi and the Intel RealSense camera in Debug mode

In Debug mode only one tcp/ip port is created. 

Time delays are very long but it allows to get full grayscale and depth images from the Realsense, in addition to the distance and tag functions.

All the functions that communicate directly with the create will still work in this mode.

The full MatlabToolbox needs to be in the Matlab path for this to work. 
